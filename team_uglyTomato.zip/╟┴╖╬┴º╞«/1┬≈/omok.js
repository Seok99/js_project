let canvas = document.getElementById("mycanvas");
let ctx = canvas.getContext("2d");
let areaArcList = [];
let whiteArcList = [];
let blackArcList = [];
let turn = "black"

    let originX = 25;
    let originY = 25;
    let lineGap = 50;
    let lineCount = 20;
function draw(){
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawGrid();
    for(let i = 0; i< whiteArcList.length; i++){
        drawArc(whiteArcList[i]);
    }
    for(let i = 0; i<blackArcList.length; i++){
        drawArc(blackArcList[i]);
    }
}
//교참점에 원형 객체 위치를 추가
function setAreaArcList(){
    // let originX = 50;
    // let originY =50;
    // let lineGap = 50;
    // let lineCount = 20;
    for(let i =0; i <lineCount; i++){
        for(let j =0; j <lineCount; j++){
            let arc={
                x : originX + j * lineGap,
                y : originY + i * lineGap,
                radius : 20,
                color : null
            };
            areaArcList.push(arc);
        }
    }
}





//마우스가 원안에 있는지 확인
function InArc(x, y, mx, my, radius){
    let hy = Math.sqrt((x -mx) ** 2 + (y -my) ** 2);//클릭위치와 원위치의 거리계산
    if(hy<=radius){
        return true;
    }
    return false;
}
//클릭시 바둑돌 놓기
window.addEventListener('click', clickmouse);
function clickmouse(e){
    let rect = canvas.getBoundingClientRect();
    let mx = e.clientX - ctx.canvas.offsetLeft + window.scrollX;
    let my = e.clientY - ctx.canvas.offsetTop + window.scrollY;
    // let mx = e.clientX - ctx.canvas.offsetLeft;
    // let my = e.clientY - ctx.canvas.offsetTop;//시작위치를 조정
    //clientX,clientY브라우저에서 사용자에게 웹페이지가 보여지는 영역을 기준으로 좌표를 표시
    for(let i =0; i <areaArcList.length; i++){
        let check = InArc(areaArcList[i].x, areaArcList[i].y, mx, my, areaArcList[i].radius);
        if(check){
            let arc = {
                x : areaArcList[i].x,
                y : areaArcList[i].y,
                radius : areaArcList[i].radius,
                color : turn
            };
            console.log(areaArcList[i]);
            areaArcList.splice(i, 1);//이미 바둑알이 놓인 위치는 배열에서 제거
            if(turn == "white"){
                whiteArcList.push(arc);
                turn = "black";
            }else{
                blackArcList.push(arc);
                turn = "white";
            }
            let winner = winnercheck();
            setTimeout(() => {//setTimeout을 이용해 바둑돌을 놓은 후 alert로 승자표시
                if(winner){
                    //settimeout
                    alert("승자:" + winner);
                }
            }, 100);
            break;
        }
    }
}
//
function drawArc(arc){
    //원 생성
    ctx.beginPath();
    ctx.arc(arc.x, arc.y, arc.radius,0, Math.PI *2);
    ctx.stroke();
    ctx.closePath();
    //원색 채우기 (이유:각각의 작업이 다른 그래픽스 상태 설정을 요구하기 때문)
    ctx.beginPath();
    ctx.arc(arc.x, arc.y, arc.radius,0, Math.PI *2);
    ctx.fillStyle = arc.color; 
    ctx.fill();
    ctx.closePath();
}

//오목판 그리드
function drawGrid(){
    ctx.beginPath();

    // let originX = 100;
    // let originY = 100;
    // let lineGap =50;
    // let lineCount =20;
    //세로그리기
    for(let i=0; i<lineCount; i++){
        let startX = originX + lineGap *i;
        let startY = originY ;
        let endX = startX;
        let endY = lineGap*(lineCount -1) + originY;
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.stroke();
    }
    //가로그리기
    for(let i=0; i<lineCount; i++){
        let startX = originX;
        let startY = originY + lineGap*i;
        let endX = originX + lineGap*(lineCount-1);
        let endY = startY;
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.stroke();
    }
    ctx.closePath();
}

let resetButton = document.querySelector("#reset");
resetButton.addEventListener('click', reset);
function reset() {
    areaArcList = [];
    whiteArcList = [];
    blackArcList = [];
    turn = "black";
    setAreaArcList();
}
// 승패구하기
function winnercheck() {
    let map = [[0, 50], [50, 0], [50, 50], [50, -50]];//Ract의 간격이 x,y가 50이기때문
    let winner = null;
    for(let color of ["white", "black"]){//흰색 검은색을 순회하여 color에 지정하고 순서대로 처리하기 위한 반복문
        for(let i =0; i<whiteArcList.length; i++){
            let arc = color === "white" ? whiteArcList[i] : blackArcList[i]//삼항연사자를 이용해 위for문에서 정해지 color가 white면 whiteArcList를 선택하기위함
            for(let d=0; d< map.length; d++){
                let count =1;
                let dx = map[d][0];
                let dy = map[d][1];
                //순방향 검사
                let x = arc.x + dx;
                let y = arc.y + dy;

                while(InList(x,y,color)){//InList로 x,y, color를 보내고 InList에 만족하면 true로 반환받아 반복문 실행
                    count++;//색이 같다면 카운트를 1개 올리고 다음 순방향 검색
                    x += dx;
                    y += dy;
                }
                //순방향 검사가 끝나면 반대방향 검사
                x = arc.x - dx;
                y = arc.y - dy;

                while(InList(x, y, color)){
                    count++;
                    x -= dx;
                    y -= dy;
                }
                //5개이상이 연속으로 나왔는지 검사
                if(count >=5){
                    winner = color;
                    break;
                }
            }
            if(winner) break;//winner가 정해졌기에 null이 아니므로 참으로 조건문만족되어 break 실행
        }
        if(winner) break;
    }
    return winner;//정해진 winner를clickmouse로 반환
}
//특정 위치에 해당 돌이 있는지 확인하는 함수
function InList(x, y, color) {
    let list = color === "white" ? whiteArcList : blackArcList
    for(let arc of list){// list의 값에 따라 반복문 실행
        //white(black)ArcList길이만큼 반복
        if(arc.x === x && arc.y === y) {
            return true;
        }
    }
    return false;
}
setAreaArcList();
setInterval(draw, 10);//반복해서 실행되는 함수의 지연을 설정


/*
    좋았던 점
    1. 만들면서 내가 원하는 js 기능을 추가적으로 공부할 수 있었다.
    2. 더부러 CSS의 다양한 기능들을 알게 되었다.
    3. 프로젝트를 만들기위해 기본을 다시 한 번 복습하기 좋은 기회였다.
    아쉬운 점 
    1. 승자가 정해진 후 돌을 놓지 못하게 만들어야했는데 그러지 못하였다.
    2. 2명의 사용자가 아니라 AI와의 대결을 추가하고 싶지만 아직 부족하여
       다음에 추가해보고 싶다.
 */